//
//  PKickoutInfo.m
//  MobileIMSDK4i
//
//  Created by Jack Jiang on 2021/7/8.
//  Copyright © 2021 cngeeker.com. All rights reserved.
//

#import "PKickoutInfo.h"

@implementation PKickoutInfo

- (id)init
{
    if(self = [super init])
    {
        self.code = -1;
    }
    return self;
}

@end
