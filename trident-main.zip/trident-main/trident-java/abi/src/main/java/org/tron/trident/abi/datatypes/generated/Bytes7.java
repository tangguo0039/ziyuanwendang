package org.tron.trident.abi.datatypes.generated;

import org.tron.trident.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.tron.trident.codegen.AbiTypesGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes7 extends Bytes {
    public static final Bytes7 DEFAULT = new Bytes7(new byte[7]);

    public Bytes7(byte[] value) {
        super(7, value);
    }
}
