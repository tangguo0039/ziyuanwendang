package org.tron.trident.abi.datatypes.generated;

import org.tron.trident.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.tron.trident.codegen.AbiTypesGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes19 extends Bytes {
    public static final Bytes19 DEFAULT = new Bytes19(new byte[19]);

    public Bytes19(byte[] value) {
        super(19, value);
    }
}
