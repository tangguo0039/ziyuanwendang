//package com.exchange.userserver;
//
//
//import com.alibaba.fastjson.JSON;
//import com.yumiao.usdttransfer.domain.UserUserDto;
//import com.yumiao.usdttransfer.service.UserUserService;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = UserServerApplication.class)
//public class UserUserServiceTests {
//
//    @Autowired
//    private UserUserService userUserService;
//
//    @Test
//    public void getUserInfoById() throws Exception {
//        UserUserDto userUserDto= userUserService.getUserInfoById(96L);
//        System.out.println(JSON.toJSONString(userUserDto));
//    }
//
//
//}
