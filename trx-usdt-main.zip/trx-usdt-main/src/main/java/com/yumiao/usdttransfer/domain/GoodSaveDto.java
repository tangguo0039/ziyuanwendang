package com.yumiao.usdttransfer.domain;

import lombok.Data;

@Data
public class GoodSaveDto {
    private Long id;
    private String goodsName;
    private Long goodsType;
}
