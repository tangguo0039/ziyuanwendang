package com.yumiao.usdttransfer.domain;

import lombok.Data;

@Data
public class UserUserDto {
    private Long userId;
    private String userName;
}
