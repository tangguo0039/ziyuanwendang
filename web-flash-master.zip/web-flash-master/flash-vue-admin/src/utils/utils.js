const apiUrl = process.env.VUE_APP_BASE_API
export function getApiUrl() {
  return apiUrl
}
