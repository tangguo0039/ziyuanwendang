<template>
  <div class="app-container">
    <div class="block">
      <iframe src="http://webflash.enilu.cn" width="100%" height="768px" frameborder="0" scrolling="auto"></iframe>


    </div>

  </div>
</template>


<style rel="stylesheet/scss" lang="scss" scoped>
  @import "src/styles/common.scss";
</style>

