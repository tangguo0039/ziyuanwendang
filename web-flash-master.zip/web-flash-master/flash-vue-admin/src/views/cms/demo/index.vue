<template>
  <div class="app-container">
    参考文档：http://webflash.enilu.cn/guide/feature/cms.html
    <div class="block">

      <el-row :gutter="20">
        <el-col :span="12">
          基于vux.li手机端cms站点<br>
          http://flash-mobile.enilu.cn/#/index<br><br>
          <iframe src="http://flash-mobile.enilu.cn/#/index" width="375px" height="600px" frameborder="0" scrolling="auto"></iframe>
        </el-col>
        <el-col :span="12">
          基于uniapp的手机端cms站点，可以一次开发，打包多端app<br>
          http://flash-uniapp.enilu.cn/<br><br>
          <iframe src="http://flash-uniapp.enilu.cn/" width="375px" height="600px" frameborder="0" scrolling="auto"></iframe>
        </el-col>

      </el-row>


    </div>

  </div>
</template>


<style rel="stylesheet/scss" lang="scss" scoped>
  @import "src/styles/common.scss";
</style>

