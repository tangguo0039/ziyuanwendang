# 克隆本项目

本项目地址为：[https://github.com/enilu/web-flash](https://github.com/enilu/web-flash),如果对你有用，欢迎给个star

如果访问github有困难，可以访问gitee地址:[https://gitee.com/enilu/web-flash](https://gitee.com/enilu/web-flash)；不用担心，这两个地址的项目代码是一致的，不存在代码和功能的差异。
项目共三个分支分别为：
- master 项目主分支：稳定版
- develop 开发分支：一些新功能或者实验性功能会先在该分支开发，不稳定
- gh-pages 项目在线文档

进入控制台输入以下命令将项目克隆到本地：
```
git clone https://github.com/enilu/web-flash.git

或者

git clone https://gitee.com/enilu/web-flash.git
```

