package cn.enilu.flash.service.system;

import cn.enilu.flash.bean.entity.system.OperationLog;
import cn.enilu.flash.dao.system.OperationLogRepository;
import cn.enilu.flash.service.BaseService;
import org.springframework.stereotype.Service;

/**
 * Created  on 2018/3/26 0026.
 *
 * @author enilu
 */
@Service
public class OperationLogService extends BaseService<OperationLog, Long, OperationLogRepository> {

}
