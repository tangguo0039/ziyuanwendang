package cn.enilu.flash.dao.test;


import cn.enilu.flash.bean.entity.test.Boy;
import cn.enilu.flash.dao.BaseRepository;


public interface BoyRepository extends BaseRepository<Boy, Long> {

}

