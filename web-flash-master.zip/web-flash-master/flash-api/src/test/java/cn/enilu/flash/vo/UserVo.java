package cn.enilu.flash.vo;

import lombok.Data;

/**
 * @author ：enilu
 * @date ：Created in 2020/3/13 0:02
 */
@Data
public class UserVo {
    private Integer sex;
    private Integer count;
}
