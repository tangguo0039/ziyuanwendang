# 克隆本项目

本项目地址为：[https://github.com/enilu/material-admin](https://github.com/enilu/material-admin),如果对你有用，欢迎给个star

项目共两个分，支分别为：
- master 项目主分支
- develop 开发分支，代码最新，但是不稳定 

进入控制台输入以下命令将项目克隆到本地：

git clone https://github.com/enilu/material-admin.git

- 使用IDEA Intellij或者eclipse导入项目，记得开发工具要安装lombook插件哦