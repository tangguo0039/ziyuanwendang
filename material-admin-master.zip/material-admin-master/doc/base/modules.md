# 基本包结构

本节详细说明本项目的基本目录结构

## material-admin模块

material-admin包含3个核心模块：
- material-core 项目核心模块，包括实体层，dao层，service层，以及各种工具类
- material-generator 代码生成模块，配合IDEA Intellij的代码生成插件：webflash-generator可以提高开发效率
- material-manage 项目web模块，包含项目页面内容，controller层 

其中material-manage是一个java web模块
其他都为java se模块，
