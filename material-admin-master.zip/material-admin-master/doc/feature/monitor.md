# 监控管理

这里的监控功能用的是alibaba druid自带的监控功能

![monitor](./img/monitor.jpg)