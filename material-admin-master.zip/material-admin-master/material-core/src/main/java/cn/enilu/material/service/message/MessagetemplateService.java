package cn.enilu.material.service.message;

import cn.enilu.material.bean.entity.message.MessageTemplate;
import cn.enilu.material.dao.message.MessagetemplateRepository;
import cn.enilu.material.service.BaseService;
import org.springframework.stereotype.Service;

/**
 * MessagetemplateService
 *
 * @author enilu
 * @version 2019/05/17 0017
 */
@Service
public class MessagetemplateService  extends BaseService<MessageTemplate,Long, MessagetemplateRepository> {

}

