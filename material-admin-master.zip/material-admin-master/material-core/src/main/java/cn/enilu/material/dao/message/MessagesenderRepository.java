package cn.enilu.material.dao.message;


import cn.enilu.material.bean.entity.message.MessageSender;
import cn.enilu.material.dao.BaseRepository;


public interface MessagesenderRepository extends BaseRepository<MessageSender,Long> {
}

